#!/bin/bash
apt-get update -y
apt-get upgrade -y
for paq in $(<Paquetes); do
apt-get install $paq -y
done
for des in $(<Descargas); do
wget $des
done
mv 'solr-9.1.0.tgz?action=download' solr-9.1.0.tgz
rm -rf Descargas
rm -rf Paquetes

groupadd Alfresco
adduser alfresco --system
usermod -aG Alfresco alfresco
groups alfresco
groupadd Solr
adduser solr --system
usermod -aG Solr solr
groups solr
mkdir -p /usr/local/{alfresco-search-services,alfresco-community73/{exiftool,activemq/{data,tmp},alf_data/keystore,alfresco-pdf-renderer,amps,amps_share,bin,imagemagick,libreoffice,licenses,modules/{platform,share},tomcat/{logs,bin,temp,conf,webapps,lib,work/Catalina/localhost,shared/{classes/alfresco/extension/keystore,lib}}}}
chgrp -R Alfresco /usr/local/alfresco-community73
chmod 775 /usr/local/alfresco-community73
chmod -R 775 /usr/local/alfresco-community73/alf_data
echo 'export ALF_HOME=/usr/local/alfresco-community73' >> /etc/environment
chgrp -R Solr /usr/local/alfresco-search-services
chmod 775 /usr/local/alfresco-search-services
echo 'export SOLR_HOME=/usr/local/alfresco-search-services' >> /etc/environment
apt-get install openjdk-17-jdk -y
echo 'export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64' >> /etc/environment
apt-get install postgresql postgresql-contrib -y
tar -xvf apache-activemq-5.16.3-bin.tar.gz
cp -R apache-activemq-5.16.3/* /usr/local/alfresco-community73/activemq/
rm -rf /etc/systemd/system/activemq.service
cp -R /root/instaladores/archivos/activemq.service /etc/systemd/system/
systemctl daemon-reload
chgrp -R Alfresco /usr/local/alfresco-community73/activemq
chown -R alfresco:Alfresco /usr/local/alfresco-community73/activemq/data
systemctl start activemq
systemctl enable activemq
ufw allow 8161/tcp
ufw allow 5672/tcp
ufw allow 61616/tcp
ufw allow 61613/tcp
chgrp -R Alfresco /usr/local/alfresco-community73/activemq/tmp
chmod -R 775 /usr/local/alfresco-community73/activemq/tmp
tar -xvf apache-tomcat-10.1.8.tar.gz
cp -R apache-tomcat-10.1.8/* /usr/local/alfresco-community73/tomcat/
chgrp -R Alfresco /usr/local/alfresco-community73
chmod -R 755 /usr/local/alfresco-community73/tomcat/bin
chmod -R 755 /usr/local/alfresco-community73/tomcat/conf
chmod -R 755 /usr/local/alfresco-community73/tomcat/shared
chmod -R 755 /usr/local/alfresco-community73/tomcat/lib
chmod -R 775 /usr/local/alfresco-community73/tomcat/temp
chmod -R 775 /usr/local/alfresco-community73/tomcat/logs
chmod -R 775 /usr/local/alfresco-community73/tomcat/work
chmod -R 775 /usr/local/alfresco-community73/tomcat/webapps
rm -rf /etc/systemd/system/tomcat.service
cp -R /root/instaladores/archivos/tomcat.service /etc/systemd/system/
systemctl daemon-reload
systemctl start tomcat
systemctl enable tomcat
ufw allow 8080/tcp
ufw allow 8443/tcp
unzip alfresco-content-services-community-distribution-7.3.0.zip -d alfresco-content-services-community-distribution-7.3
cp alfresco-content-services-community-distribution-7.3/keystore/CreateSSLKeystores.txt /usr/local/alfresco-community73/alf_data/keystore/
cp alfresco-content-services-community-distribution-7.3/keystore/generate_keystores.sh /usr/local/alfresco-community73/alf_data/keystore/
cp alfresco-content-services-community-distribution-7.3/keystore/readme.txt /usr/local/alfresco-community73/alf_data/keystore/
chgrp -R Alfresco /usr/local/alfresco-community73/alf_data/keystore
chmod -R 755 /usr/local/alfresco-community73/alf_data/keystore
unzip alfresco-governance-services-community-distribution-7.3.0.zip
cp -R alfresco-governance-services-community-repo-17.183.amp /usr/local/alfresco-community73/amps/
cp -R alfresco-governance-services-community-share-17.138.amp /usr/local/alfresco-community73/amps_share/
cp alfresco-content-services-community-distribution-7.3/amps/alfresco-share-services.amp /usr/local/alfresco-community73/amps/
cp support-tools-repo-1.1.0.0-amp.amp /usr/local/alfresco-community73/amps/
cp javascript-console-repo-0.7.amp /usr/local/alfresco-community73/amps/
cp support-tools-share-1.1.0.0-amp.amp /usr/local/alfresco-community73/amps_share/
cp javascript-console-share-0.7.amp /usr/local/alfresco-community73/amps_share/
cp -R alfresco-aos-module-1.5.0.amp /usr/local/alfresco-community73/amps/
chgrp -R Alfresco /usr/local/alfresco-community73/amps 
chgrp -R Alfresco /usr/local/alfresco-community73/amps_share
chmod -R 755 /usr/local/alfresco-community73/amps 
chmod -R 755 /usr/local/alfresco-community73/amps_share
cp alfresco-content-services-community-distribution-7.3/bin/alfresco-mmt.jar /usr/local/alfresco-community73/bin/
cp alfresco-content-services-community-distribution-7.3/bin/apply_amps.sh /usr/local/alfresco-community73/bin/
cp alfresco-content-services-community-distribution-7.3/bin/clean_tomcat.sh /usr/local/alfresco-community73/bin/
chgrp -R Alfresco /usr/local/alfresco-community73/bin
chmod -R 755 /usr/local/alfresco-community73/bin
cp -R alfresco-content-services-community-distribution-7.3/licenses/* /usr/local/alfresco-community73/licenses/
chgrp -R Alfresco /usr/local/alfresco-community73/licenses
cp -R alfresco-content-services-community-distribution-7.3/web-server/conf/* /usr/local/alfresco-community73/tomcat/conf/
cp alfresco-content-services-community-distribution-7.3/web-server/lib/* /usr/local/alfresco-community73/tomcat/lib/
chgrp -R Alfresco /usr/local/alfresco-community73/tomcat/lib
chmod 755 /usr/local/alfresco-community73/tomcat/lib/*.jar
cp -R alfresco-content-services-community-distribution-7.3/web-server/shared/classes/* /usr/local/alfresco-community73/tomcat/shared/classes/
cp -R alfresco-content-services-community-distribution-7.3/keystore/metadata-keystore /usr/local/alfresco-community73/tomcat/shared/classes/alfresco/extension/keystore
echo 'JAVA_TOOL_OPTIONS="-Dencryption.keystore.type=JCEKS -Dencryption.cipherAlgorithm=DESede/CBC/PKCS5Padding -Dencryption.keyAlgorithm=DESede -Dencryption.keystore.location=/usr/local/alfresco-community73/tomcat/shared/classes/alfresco/extension/keystore/metadata-keystore/keystore -Dmetadata-keystore.password=mp6yc0UD9e -Dmetadata-keystore.aliases=metadata -Dmetadata-keystore.metadata.password=oKIWzVdEdA -Dmetadata-keystore.metadata.algorithm=DESede"' >> /etc/environment
chgrp -R Alfresco /usr/local/alfresco-community73/tomcat/shared
chmod -R 755 /usr/local/alfresco-community73/tomcat/shared
rm -rf /usr/local/alfresco-community73/tomcat/webapps/*
cp alfresco-content-services-community-distribution-7.3/web-server/webapps/*.war /usr/local/alfresco-community73/tomcat/webapps/
chgrp -R Alfresco /usr/local/alfresco-community73/tomcat/webapps/
chmod -R 775 /usr/local/alfresco-community73/tomcat/webapps/*.war
rm -rf /usr/local/alfresco-community73/tomcat/work/Catalina/localhost/*
chgrp -R Alfresco /usr/local/alfresco-community73/tomcat/work/Catalina/localhost
chmod -R 775 /usr/local/alfresco-community73/tomcat/work/Catalina/localhost
rm -rf /usr/local/alfresco-community73/tomcat/conf/server.xml
cp -R /root/instaladores/archivos/server.xml /usr/local/alfresco-community73/tomcat/conf/
rm -rf /usr/local/alfresco-community73/tomcat/conf/catalina.properties
cp -R /root/instaladores/archivos/catalina.properties /usr/local/alfresco-community73/tomcat/conf/
rm -rf /usr/local/alfresco-community73/tomcat/bin/catalina.sh
cp -R /root/instaladores/archivos/catalina.sh /usr/local/alfresco-community73/tomcat/bin/
mv /usr/local/alfresco-community73/tomcat/shared/classes/alfresco-global.properties.sample /usr/local/alfresco-community73/tomcat/shared/classes/alfresco-global.properties
chgrp Alfresco /usr/local/alfresco-community73/tomcat/shared/classes/alfresco-global.properties
chmod 775 /usr/local/alfresco-community73/tomcat/shared/classes/alfresco-global.properties
rm -rf /usr/local/alfresco-community73/tomcat/shared/classes/alfresco-global.properties
cp -R /root/instaladores/archivos/alfresco-global.properties /usr/local/alfresco-community73/tomcat/shared/classes/
ln -s /usr/bin/convert /usr/local/alfresco-community73/imagemagick
ln -s /usr/lib/x86_64-linux-gnu/ImageMagick-6.9.10/config-Q16HDRI /usr/local/alfresco-community73/imagemagick
ln -s /usr/lib/x86_64-linux-gnu/ImageMagick-6.9.10/modules-Q16HDRI /usr/local/alfresco-community73/imagemagick
ln -s /etc/libreoffice/* /usr/local/alfresco-community73/libreoffice
tar -xvf alfresco-pdf-renderer-1.1-linux.tgz
cp alfresco-pdf-renderer /usr/local/alfresco-community73/alfresco-pdf-renderer/
chgrp -R Alfresco /usr/local/alfresco-community73/alfresco-pdf-renderer
chmod -R 755 /usr/local/alfresco-community73/alfresco-pdf-renderer
tar -xvf Image-ExifTool-12.55.tar.gz
cp -R Image-ExifTool-12.55/* /usr/local/alfresco-community73/exiftool/
chgrp -R Alfresco /usr/local/alfresco-community73/exiftool
chmod -R 755 /usr/local/alfresco-community73/exiftool
cp alfresco-transform-core-aio-boot-2.4.0.jar /usr/local/alfresco-community73/bin/
chgrp Alfresco /usr/local/alfresco-community73/bin/alfresco-transform-core-aio-boot-2.4.0.jar
chmod 755 /usr/local/alfresco-community73/bin/alfresco-transform-core-aio-boot-2.4.0.jar
rm -rf /usr/local/alfresco-community73/localTransformationService.sh
cp -R /root/instaladores/archivos/localTransformationService.sh /usr/local/alfresco-community73/
chgrp Alfresco /usr/local/alfresco-community73/localTransformationService.sh
chmod 755 /usr/local/alfresco-community73/localTransformationService.sh
rm -rf /etc/systemd/system/localTransform.service
cp -R /root/instaladores/archivos/localTransform.service /etc/systemd/system/
ufw allow 8090/tcp
systemctl daemon-reload
systemctl start localTransform
systemctl enable localTransform
mv /usr/local/alfresco-community73/tomcat/shared/classes/alfresco/extension/custom-log4j.properties.sample /usr/local/alfresco-community73/tomcat/shared/classes/alfresco/extension/custom-log4j.properties
/usr/local/alfresco-community73/bin/apply_amps.sh
chmod -R 775 /usr/local/alfresco-community73/tomcat/webapps/*.war
rm -rf /usr/local/alfresco-community73/tomcat/shared/classes/alfresco/web-extension/share-config-custom.xml 
cp -R /root/instaladores/archivos/share-config-custom.xml  /usr/local/alfresco-community73/tomcat/shared/classes/alfresco/web-extension/
tar -xvf solr-9.1.0.tgz
unzip alfresco-search-services-2.0.5.zip -d alfresco-search-services-2.0.5
rm -rf alfresco-search-services-2.0.5/alfresco-search-services/solr/*
cp -R solr-9.1.0/* alfresco-search-services-2.0.5/alfresco-search-services/solr/ 
cp -R alfresco-search-services-2.0.5/alfresco-search-services/* /usr/local/alfresco-search-services/
chown -R solr:Solr /usr/local/alfresco-search-services
chmod -R 755 /usr/local/alfresco-search-services
chmod -R 775 /usr/local/alfresco-search-services/logs
chmod -R 775 /usr/local/alfresco-search-services/solrhome
rm -rf /usr/local/alfresco-search-services/solrhome/conf/shared.properties
cp -R /root/instaladores/archivos/shared.properties /usr/local/alfresco-search-services/solrhome/conf/
rm -rf /usr/local/alfresco-search-services/solr.in.sh
cp -R /root/instaladores/archivos/solr.in.sh /usr/local/alfresco-search-services/
rm -rf /usr/local/alfresco-search-services/solrhome/templates/rerank/conf/solrcore.properties
cp -R /root/instaladores/archivos/solrcore.properties /usr/local/alfresco-search-services/solrhome/templates/rerank/conf/
rm -rf /etc/systemd/system/solr.service
cp -R /root/instaladores/archivos/solr.service /etc/systemd/system/
systemctl daemon-reload
systemctl start solr
systemctl enable solr
ufw allow 8983/tcp
rm -rf Download.sh
chgrp -R Alfresco /usr/local/alfresco-community73
chmod -R 755 /usr/local/alfresco-community73/tomcat/bin
chmod -R 755 /usr/local/alfresco-community73/tomcat/conf
chmod -R 755 /usr/local/alfresco-community73/tomcat/shared
chmod -R 755 /usr/local/alfresco-community73/tomcat/lib
chmod -R 775 /usr/local/alfresco-community73/tomcat/temp
chmod -R 775 /usr/local/alfresco-community73/tomcat/logs
chmod -R 775 /usr/local/alfresco-community73/tomcat/work
chmod -R 775 /usr/local/alfresco-community73/tomcat/webapps
sudo -u solr /usr/local/alfresco-search-services/solr/bin/solr create_core -c alfresco -d _default
sudo -u solr /usr/local/alfresco-search-services/solr/bin/solr create_core -c archive -d _default
echo ":"
echo ":"
echo ":"
echo ":"
echo "Por favor configure la base de datos Postgres:"
echo ":"
echo ":"
echo ":"

